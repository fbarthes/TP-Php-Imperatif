<?php

header('location: http://localhost/phpimp%C3%A9ratif');