<?php

function afficheAjouter() {
    echo "<a href='?method=create&cle=false'>Ajouter</a>";
}