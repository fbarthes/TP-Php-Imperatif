    <header>
        <nav>
            <ul>
                <li><a href="<?php echo generateUrl('simpleDatas','displayAll'); ?>">Liste des données</a></li>
                <?php if(is_connected()): ?>
                <li><a href="<?php echo generateUrl('simpleDatas','createData'); ?>">Ajouter</a></li>
                <?php endif; ?>
                <li><a href="<?php echo generateUrl('multiplie','displayMultiplie'); ?>">Tables de multiplication</a></li>
                <?php 
                    if(!is_connected()):
                ?>
                <li><a href="<?php echo generateUrl('security','login'); ?>">Se connecter</a></li>
                <li><a href="<?php echo generateUrl('security','registration'); ?>">S'enregistrer</a></li>
                <?php
                    else:
                ?>
                <li><a href="<?php echo generateUrl('avatar','loadAvatar'); ?>">Téléchargez votre avatar</a></li>
                <li><a href="<?php echo generateUrl('security','disconnect'); ?>">Se déconnecter</a></li>
                <?php
                    endif;
                ?>
            </ul>
        </nav>
    </header>
