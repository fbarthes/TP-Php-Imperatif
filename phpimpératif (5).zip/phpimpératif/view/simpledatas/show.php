<main>
    <h2>Affichage d'une enregistrement</h2>
    <?php echo $data; ?>
</main>