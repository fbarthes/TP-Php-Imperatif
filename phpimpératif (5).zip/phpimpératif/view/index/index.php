<main>
    Autre page
</main>