<main>
    <?php echo $form; ?>
</main>