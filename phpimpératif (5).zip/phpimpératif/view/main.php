<main>
    <?php echo $content; ?>
</main>