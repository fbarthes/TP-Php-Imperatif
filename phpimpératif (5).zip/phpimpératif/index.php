<?php
include_once('dwwm/kernel.php');

routeur();