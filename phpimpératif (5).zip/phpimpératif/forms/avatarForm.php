<?php

function constructAvatarForm()
{
    return "<form method='POST' action='".generateUrl('avatar','loadAvatar')."' enctype='multipart/form-data'>
        <input type='file' name='avatar' />
        <input type='submit' name='submit' value='télécharger'>
    </form>";
}